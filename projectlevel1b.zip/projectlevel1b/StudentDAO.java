import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class StudentDAO {

    // ==============================
    // Student Registration
    // ==============================

    public static boolean registerStudent(Student student) {

        try {

            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO students(name,username,password,skills,cgpa) VALUES(?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, student.getName());
            ps.setString(2, student.getUsername());
            ps.setString(3, student.getPassword());
            ps.setString(4, student.getSkills());
            ps.setDouble(5, student.getCgpa());

            int row = ps.executeUpdate();

            return row > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    // ==============================
    // Student Login
    // ==============================

    public static Student loginStudent(String username, String password) {

        Student student = null;

        try {

            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM students WHERE username=? AND password=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                student = new Student();

                student.setStudentId(rs.getInt("student_id"));
                student.setName(rs.getString("name"));
                student.setUsername(rs.getString("username"));
                student.setPassword(rs.getString("password"));
                student.setSkills(rs.getString("skills"));
                student.setCgpa(rs.getDouble("cgpa"));

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return student;
    }

    // ==============================
    // View Profile
    // ==============================

    public static void viewProfile(Student student) {

        System.out.println("\n========== STUDENT PROFILE ==========");
        System.out.println("Student ID : " + student.getStudentId());
        System.out.println("Name       : " + student.getName());
        System.out.println("Username   : " + student.getUsername());
        System.out.println("Skills     : " + student.getSkills());
        System.out.println("CGPA       : " + student.getCgpa());
        System.out.println("=====================================");
    }

    // ==============================
    // Update Profile
    // ==============================

    public static boolean updateProfile(Student student) {

        try {

            Connection con = DBConnection.getConnection();

            String sql = "UPDATE students SET name=?, password=? WHERE student_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, student.getName());
            ps.setString(2, student.getPassword());
            ps.setInt(3, student.getStudentId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    // ==============================
    // Update Skills
    // ==============================

    public static boolean updateSkills(int studentId, String skills) {

        try {

            Connection con = DBConnection.getConnection();

            String sql = "UPDATE students SET skills=? WHERE student_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, skills);
            ps.setInt(2, studentId);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    // ==============================
    // Update CGPA
    // ==============================

    public static boolean updateCGPA(int studentId, double cgpa) {

        try {

            Connection con = DBConnection.getConnection();

            String sql = "UPDATE students SET cgpa=? WHERE student_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setDouble(1, cgpa);
            ps.setInt(2, studentId);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }
    // ====================================
// View All Students
// ====================================

public static void viewAllStudents() {

    try {

        Connection con = DBConnection.getConnection();

        String sql = "SELECT * FROM students";

        PreparedStatement ps = con.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        System.out.println("\n========== STUDENT LIST ==========");

        while (rs.next()) {

            System.out.println("----------------------------------");
            System.out.println("Student ID : " + rs.getInt("student_id"));
            System.out.println("Name       : " + rs.getString("name"));
            System.out.println("Username   : " + rs.getString("username"));
            System.out.println("Skills     : " + rs.getString("skills"));
            System.out.println("CGPA       : " + rs.getDouble("cgpa"));
        }

        System.out.println("----------------------------------");

    } catch (Exception e) {

        e.printStackTrace();

    }

}
// ====================================
// Filter Students By CGPA
// ====================================

public static void filterStudentsByCGPA(double cgpa) {

    try {

        Connection con = DBConnection.getConnection();

        String sql = "SELECT * FROM students WHERE cgpa >= ?";

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setDouble(1, cgpa);

        ResultSet rs = ps.executeQuery();

        System.out.println("\n===== ELIGIBLE STUDENTS =====");

        boolean found = false;

        while (rs.next()) {

            found = true;

            System.out.println("----------------------------------");
            System.out.println("Student ID : " + rs.getInt("student_id"));
            System.out.println("Name       : " + rs.getString("name"));
            System.out.println("Skills     : " + rs.getString("skills"));
            System.out.println("CGPA       : " + rs.getDouble("cgpa"));
        }

        if (!found) {
            System.out.println("No Student Found.");
        }

        System.out.println("----------------------------------");

    } catch (Exception e) {

        e.printStackTrace();

    }

}

}