
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class CompanyDAO {

    static Scanner sc = new Scanner(System.in);

    // ==========================================
    // View All Companies
    // ==========================================

    public static void viewCompanies() {

        try {

            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM companies";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            System.out.println("\n==============================================================");
            System.out.printf("%-5s %-20s %-20s %-8s %-8s\n",
                    "ID", "Company", "Skills", "CGPA", "Vacancy");
            System.out.println("==============================================================");

            while (rs.next()) {

                System.out.printf("%-5d %-20s %-20s %-8.2f %-8d\n",

                        rs.getInt("company_id"),
                        rs.getString("company_name"),
                        rs.getString("required_skills"),
                        rs.getDouble("minimum_cgpa"),
                        rs.getInt("vacancies"));

            }

            System.out.println("==============================================================");

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    // ==========================================
    // Add Company
    // ==========================================

    public static void addCompany() {

        try {

            Company company = new Company();

            System.out.print("Company Name : ");
            company.setCompanyName(sc.nextLine());

            System.out.print("Required Skills : ");
            company.setRequiredSkills(sc.nextLine());

            System.out.print("Minimum CGPA : ");
            company.setMinimumCgpa(sc.nextDouble());

            System.out.print("Vacancies : ");
            company.setVacancies(sc.nextInt());

            sc.nextLine();

            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO companies(company_name,required_skills,minimum_cgpa,vacancies) VALUES(?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, company.getCompanyName());
            ps.setString(2, company.getRequiredSkills());
            ps.setDouble(3, company.getMinimumCgpa());
            ps.setInt(4, company.getVacancies());

            if (ps.executeUpdate() > 0) {

                System.out.println("\nCompany Added Successfully.");

            } else {

                System.out.println("\nFailed.");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    // ==========================================
    // Apply Company
    // ==========================================

    /*public static void applyCompany(Student student) {

        try {

            viewCompanies();

            System.out.print("\nEnter Company ID : ");

            int companyId = sc.nextInt();
            sc.nextLine();

            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO applications(student_id,company_id,status) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, student.getStudentId());
            ps.setInt(2, companyId);
            ps.setString(3, "Applied");

            if (ps.executeUpdate() > 0) {

                System.out.println("\nApplication Submitted Successfully.");

            } else {

                System.out.println("\nApplication Failed.");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

    }*/

    // ==========================================
    // Delete Company
    // ==========================================

    public static void deleteCompany() {

        try {

            System.out.print("Enter Company ID : ");

            int id = sc.nextInt();
            sc.nextLine();

            Connection con = DBConnection.getConnection();

            String sql = "DELETE FROM companies WHERE company_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            if (ps.executeUpdate() > 0) {

                System.out.println("\nCompany Deleted.");

            } else {

                System.out.println("\nCompany Not Found.");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

}