public class Student {

    // Instance Variables
    private int studentId;
    private String name;
    private String username;
    private String password;
    private String skills;
    private double cgpa;

    // Default Constructor
    public Student() {

    }

    // Parameterized Constructor
    public Student(int studentId, String name, String username,
                   String password, String skills, double cgpa) {

        this.studentId = studentId;
        this.name = name;
        this.username = username;
        this.password = password;
        this.skills = skills;
        this.cgpa = cgpa;
    }

    // Getters

    public int getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getSkills() {
        return skills;
    }

    public double getCgpa() {
        return cgpa;
    }

    // Setters

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public void setCgpa(double cgpa) {
        this.cgpa = cgpa;
    }

    // Display Student Details
    @Override
    public String toString() {
        return "\n========== STUDENT PROFILE ==========\n" +
               "Student ID : " + studentId +
               "\nName       : " + name +
               "\nUsername   : " + username +
               "\nSkills     : " + skills +
               "\nCGPA       : " + cgpa +
               "\n=====================================";
    }
}
