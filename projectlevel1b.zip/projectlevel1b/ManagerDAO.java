import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ManagerDAO {

    // ==========================
    // Manager Registration
    // ==========================
    public static boolean registerManager(Manager manager) {

        try {

            Connection con = DBConnection.getConnection();

            String query = "INSERT INTO managers(name, username, password) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, manager.getName());
            ps.setString(2, manager.getUsername());
            ps.setString(3, manager.getPassword());

            int row = ps.executeUpdate();

            return row > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // ==========================
    // Manager Login
    // ==========================
    public static boolean loginManager(String username, String password) {

        try {

            Connection con = DBConnection.getConnection();

            String query = "SELECT * FROM managers WHERE username=? AND password=?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
