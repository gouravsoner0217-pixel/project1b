import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class HRDAO {

    // ==========================
    // HR Registration
    // ==========================
    public static boolean registerHR(HR hr) {

        try {

            Connection con = DBConnection.getConnection();

            String query = "INSERT INTO hr(name, username, password) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, hr.getName());
            ps.setString(2, hr.getUsername());
            ps.setString(3, hr.getPassword());

            int row = ps.executeUpdate();

            if (row > 0) {
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // ==========================
    // HR Login
    // ==========================
    public static boolean loginHR(String username, String password) {

        try {

            Connection con = DBConnection.getConnection();

            String query = "SELECT * FROM hr WHERE username=? AND password=?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

}