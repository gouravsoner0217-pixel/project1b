import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Scanner;

public class ApplicationDAO {

    static Scanner sc = new Scanner(System.in);

    // ==========================================
    // Student Apply For Company
    // ==========================================

    public static void applyForCompany(Student student) {

        try {

            // Show all companies
            CompanyDAO.viewCompanies();

            System.out.print("\nEnter Company ID : ");
            int companyId = sc.nextInt();
            sc.nextLine();

            Connection con = DBConnection.getConnection();

            // ---------------------------------------
            // Check Company Details
            // ---------------------------------------

            String companyQuery =
                    "SELECT * FROM companies WHERE company_id=?";

            PreparedStatement cps =
                    con.prepareStatement(companyQuery);

            cps.setInt(1, companyId);

            ResultSet company =
                    cps.executeQuery();

            if (!company.next()) {

                System.out.println("\nCompany Not Found.");
                return;

            }

            String companyName =
                    company.getString("company_name");

            String requiredSkill =
                    company.getString("required_skills");

            double minimumCGPA =
                    company.getDouble("minimum_cgpa");

            int vacancies =
                    company.getInt("vacancies");

            // ---------------------------------------
            // Already Applied ?
            // ---------------------------------------

            String checkApplication =
                    "SELECT * FROM applications WHERE student_id=? AND company_id=?";

            PreparedStatement aps =
                    con.prepareStatement(checkApplication);

            aps.setInt(1, student.getStudentId());
            aps.setInt(2, companyId);

            ResultSet already =
                    aps.executeQuery();

            if (already.next()) {

                System.out.println("\nYou have already applied to this company.");
                return;

            }

            // ---------------------------------------
            // Vacancy Check
            // ---------------------------------------

            if (vacancies <= 0) {

                System.out.println("\nNo Vacancy Available.");
                return;

            }

            // ---------------------------------------
            // CGPA Check
            // ---------------------------------------

            if (student.getCgpa() < minimumCGPA) {

                System.out.println("\nApplication Rejected!");
                System.out.println("Reason : CGPA is below requirement.");
                System.out.println("Required : " + minimumCGPA);
                System.out.println("Your CGPA : " + student.getCgpa());

                return;

            }
// ---------------------------------------
// Skill Check
// ---------------------------------------

String[] companySkills = requiredSkill.toLowerCase().split(",");
String studentSkills = student.getSkills().toLowerCase();

boolean skillMatched = false;

for (String skill : companySkills) {

    if (studentSkills.contains(skill.trim())) {

        skillMatched = true;
        break;

    }

}

if (!skillMatched) {

    System.out.println("\nApplication Rejected!");
    System.out.println("Reason : No Required Skill Matched.");

    return;

}

            // ---------------------------------------
            // Save Application
            // ---------------------------------------

            String applyQuery =
                    "INSERT INTO applications(student_id,company_id,application_date,status) VALUES(?,?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(applyQuery);

            ps.setInt(1, student.getStudentId());
            ps.setInt(2, companyId);
            ps.setDate(3, java.sql.Date.valueOf(LocalDate.now()));
            ps.setString(4, "Applied");

            int row = ps.executeUpdate();

            if (row > 0) {

                System.out.println("\n=================================");
                System.out.println("Application Submitted Successfully");
                System.out.println("Company : " + companyName);
                System.out.println("Status  : Applied");
                System.out.println("=================================");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
// ==========================================
// Student - View My Applications
// ==========================================

public static void viewMyApplications(Student student) {

    try {

        Connection con = DBConnection.getConnection();

        String sql =
        "SELECT a.application_id, c.company_name, a.application_date, a.status " +
        "FROM applications a " +
        "JOIN companies c ON a.company_id = c.company_id " +
        "WHERE a.student_id=?";

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setInt(1, student.getStudentId());

        ResultSet rs = ps.executeQuery();

        boolean found = false;

        System.out.println("\n========== MY APPLICATIONS ==========");

        while (rs.next()) {

            found = true;

            System.out.println("------------------------------------");
            System.out.println("Application ID : " + rs.getInt("application_id"));
            System.out.println("Company        : " + rs.getString("company_name"));
            System.out.println("Applied Date   : " + rs.getDate("application_date"));
            System.out.println("Status         : " + rs.getString("status"));

        }

        if (!found) {

            System.out.println("No Applications Found.");

        }

        System.out.println("------------------------------------");

    } catch (Exception e) {

        e.printStackTrace();

    }

}
// ==========================================
// HR - View All Applications
// ==========================================

public static void viewAllApplications() {

    try {

        Connection con = DBConnection.getConnection();

        String sql =
        "SELECT a.application_id, s.name, c.company_name, a.application_date, a.status " +
        "FROM applications a " +
        "JOIN students s ON a.student_id=s.student_id " +
        "JOIN companies c ON a.company_id=c.company_id";

        PreparedStatement ps = con.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        System.out.println("\n========== ALL APPLICATIONS ==========");

        while (rs.next()) {

            System.out.println("------------------------------------");
            System.out.println("Application ID : " + rs.getInt("application_id"));
            System.out.println("Student Name   : " + rs.getString("name"));
            System.out.println("Company        : " + rs.getString("company_name"));
            System.out.println("Applied Date   : " + rs.getDate("application_date"));
            System.out.println("Status         : " + rs.getString("status"));

        }

        System.out.println("------------------------------------");

    } catch (Exception e) {

        e.printStackTrace();

    }

}
// ==========================================
// Update Application Status
// ==========================================

public static void updateApplicationStatus(String status) {

    try {

        System.out.print("Enter Application ID : ");
        int applicationId = sc.nextInt();
        sc.nextLine();

        Connection con = DBConnection.getConnection();

        // Get current application details
        String checkQuery =
                "SELECT company_id, status FROM applications WHERE application_id=?";

        PreparedStatement checkPs = con.prepareStatement(checkQuery);
        checkPs.setInt(1, applicationId);

        ResultSet rs = checkPs.executeQuery();

        if (!rs.next()) {

            System.out.println("Application Not Found.");
            return;

        }

        int companyId = rs.getInt("company_id");
        String currentStatus = rs.getString("status");

        // Prevent duplicate approval
        if (currentStatus.equalsIgnoreCase(status)) {

            System.out.println("Application is already " + status + ".");
            return;

        }

        // If approving, check vacancy first
        if (status.equalsIgnoreCase("Approved")) {

            String vacancyQuery =
                    "SELECT vacancies FROM companies WHERE company_id=?";

            PreparedStatement vacancyPs =
                    con.prepareStatement(vacancyQuery);

            vacancyPs.setInt(1, companyId);

            ResultSet vacancyRs = vacancyPs.executeQuery();

            if (vacancyRs.next()) {

                int vacancies = vacancyRs.getInt("vacancies");

                if (vacancies <= 0) {

                    System.out.println("No Vacancies Available.");
                    return;

                }

            }

        }

        // Update application status
        String updateQuery =
                "UPDATE applications SET status=? WHERE application_id=?";

        PreparedStatement updatePs =
                con.prepareStatement(updateQuery);

        updatePs.setString(1, status);
        updatePs.setInt(2, applicationId);

        int row = updatePs.executeUpdate();

        if (row > 0) {

            // Reduce vacancy only when approved
            if (status.equalsIgnoreCase("Approved")) {

                String reduceQuery =
                        "UPDATE companies SET vacancies = vacancies - 1 WHERE company_id=?";

                PreparedStatement reducePs =
                        con.prepareStatement(reduceQuery);

                reducePs.setInt(1, companyId);

                reducePs.executeUpdate();

                // Show remaining vacancies
                String showQuery =
                        "SELECT vacancies FROM companies WHERE company_id=?";

                PreparedStatement showPs =
                        con.prepareStatement(showQuery);

                showPs.setInt(1, companyId);

                ResultSet showRs = showPs.executeQuery();

                if (showRs.next()) {

                    System.out.println("\nApplication Approved Successfully.");
                    System.out.println("Remaining Vacancies : "
                            + showRs.getInt("vacancies"));

                }

            } else {

                System.out.println("\nApplication " + status + " Successfully.");

            }

        }

    } catch (Exception e) {

        e.printStackTrace();

    }



}
public static void approveApplication() {

    updateApplicationStatus("Approved");

}
public static void rejectApplication() {

    updateApplicationStatus("Rejected");

}
public static void shortlistApplication() {

    updateApplicationStatus("Shortlisted");

}
public static void viewShortlistedApplications() {

    try {

        Connection con = DBConnection.getConnection();

        String sql = "SELECT * FROM applications WHERE status = ?";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, "Shortlisted");

        ResultSet rs = ps.executeQuery();

        System.out.println("\n========== Shortlisted Applications ==========");

        boolean found = false;

        while (rs.next()) {

            found = true;

            System.out.println("--------------------------------------");
            System.out.println("Application ID : " + rs.getInt("application_id"));
            System.out.println("Student ID     : " + rs.getInt("student_id"));
            System.out.println("Company ID     : " + rs.getInt("company_id"));
            System.out.println("Status         : " + rs.getString("status"));
        }

        if (!found) {
            System.out.println("No shortlisted applications found.");
        }

        con.close();

    } catch (Exception e) {
        System.out.println(e);
    }
}
}