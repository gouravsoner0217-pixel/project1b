import java.util.Scanner;

public class ManagerService {

    static Scanner sc = new Scanner(System.in);

    public static void managerMenu() {

        int choice;

        do {

            System.out.println("\n======================================");
            System.out.println("         MANAGER DASHBOARD");
            System.out.println("======================================");
            System.out.println("1. View All Students");
            System.out.println("2. Assign Task");
            System.out.println("3. View Tasks");
            System.out.println("4. Update Task Status");
            System.out.println("5. Logout");
            System.out.print("Enter Choice : ");

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    StudentDAO.viewAllStudents();
                    break;

                case 2:
                    TaskDAO.assignTask();
                    break;

                case 3:
                    TaskDAO.viewTasks();
                    break;

                case 4:
                    TaskDAO.updateTaskStatus();
                    break;

                case 5:
                    System.out.println("\nLogged Out Successfully...");
                    break;

                default:
                    System.out.println("\nInvalid Choice!");

            }

        } while (choice != 5);

    }

}