public class HR {

    // Instance Variables
    private int hrId;
    private String name;
    private String username;
    private String password;

    // Default Constructor
    public HR() {

    }

    // Parameterized Constructor
    public HR(int hrId, String name, String username, String password) {
        this.hrId = hrId;
        this.name = name;
        this.username = username;
        this.password = password;
    }

    // Getters
    public int getHrId() {
        return hrId;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    // Setters
    public void setHrId(int hrId) {
        this.hrId = hrId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Display HR Details
    @Override
    public String toString() {
        return "\n========== HR DETAILS ==========\n" +
               "HR ID     : " + hrId +
               "\nName      : " + name +
               "\nUsername  : " + username +
               "\n================================";
    }
}
