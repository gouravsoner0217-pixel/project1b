import java.util.Scanner;

public class Register {

    static Scanner sc = new Scanner(System.in);

    public static void registerMenu() {

        int choice;

        do {

            System.out.println("\n=================================");
            System.out.println("          REGISTER");
            System.out.println("=================================");
            System.out.println("1. Student Register");
            System.out.println("2. HR Register");
            System.out.println("3. Manager Register");
            System.out.println("4. Back");
            System.out.print("Enter Choice : ");

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    if(studentRegister()){
                        return;
                    }
                    break;

                case 2:
                    if(hrRegister()){
                        return;
                    }
                    break;

                case 3:
                    if(managerRegister()){
                        return;
                    }
                    break;

                case 4:
                    System.out.println("Returning...");
                    break;

                default:
                    System.out.println("Invalid Choice!");
            }

        } while (choice != 4);

    }

    // ===========================
    // Student Registration
    // ===========================

    public static boolean studentRegister() {

        Student s = new Student();

        System.out.print("Enter Name : ");
        s.setName(sc.nextLine());

        System.out.print("Enter Username : ");
        s.setUsername(sc.nextLine());

        System.out.print("Enter Password : ");
        s.setPassword(sc.nextLine());

        System.out.print("Enter Skills : ");
        s.setSkills(sc.nextLine());

        System.out.print("Enter CGPA : ");
        s.setCgpa(sc.nextDouble());
        sc.nextLine();

        if (StudentDAO.registerStudent(s)) {
            System.out.println("\nStudent Registered Successfully!");
            return true;
        } else {
            System.out.println("\nRegistration Failed!");
            return false;
        }

    }

    // ===========================
    // HR Registration
    // ===========================

    public static boolean hrRegister() {

        HR hr = new HR();

        System.out.print("Enter Name : ");
        hr.setName(sc.nextLine());

        System.out.print("Enter Username : ");
        hr.setUsername(sc.nextLine());

        System.out.print("Enter Password : ");
        hr.setPassword(sc.nextLine());

        if (HRDAO.registerHR(hr)) {
            System.out.println("\nHR Registered Successfully!");
            return true;
        } else {
            System.out.println("\nRegistration Failed!");
            return false;
        }

    }

    // ===========================
    // Manager Registration
    // ===========================

    public static boolean managerRegister() {

        Manager manager = new Manager();

        System.out.print("Enter Name : ");
        manager.setName(sc.nextLine());

        System.out.print("Enter Username : ");
        manager.setUsername(sc.nextLine());

        System.out.print("Enter Password : ");
        manager.setPassword(sc.nextLine());

        if (ManagerDAO.registerManager(manager)) {
            System.out.println("\nManager Registered Successfully!");
            return true;
        } else {
            System.out.println("\nRegistration Failed!");
            return false;
        }

    }

}