public class Performance {

    private int performanceId;
    private int studentId;
    private int managerId;
    private int taskId;
    private int marks;
    private String remarks;
    private String grade;

    // Default Constructor
    public Performance() {

    }

    // Parameterized Constructor
    public Performance(int performanceId, int studentId, int managerId,
                       int taskId, int marks, String remarks, String grade) {

        this.performanceId = performanceId;
        this.studentId = studentId;
        this.managerId = managerId;
        this.taskId = taskId;
        this.marks = marks;
        this.remarks = remarks;
        this.grade = grade;
    }

    // Getters

    public int getPerformanceId() {
        return performanceId;
    }

    public int getStudentId() {
        return studentId;
    }

    public int getManagerId() {
        return managerId;
    }

    public int getTaskId() {
        return taskId;
    }

    public int getMarks() {
        return marks;
    }

    public String getRemarks() {
        return remarks;
    }

    public String getGrade() {
        return grade;
    }

    // Setters

    public void setPerformanceId(int performanceId) {
        this.performanceId = performanceId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {

        return "\n========== PERFORMANCE ==========" +
               "\nPerformance ID : " + performanceId +
               "\nStudent ID     : " + studentId +
               "\nManager ID     : " + managerId +
               "\nTask ID        : " + taskId +
               "\nMarks          : " + marks +
               "\nGrade          : " + grade +
               "\nRemarks        : " + remarks +
               "\n=================================";

    }

}
