import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        int choice;

        do {

            System.out.println("============================================================");
            System.out.println("   ====>^.^<==== SMART INTERNSHIP ANALYSER ====>^.^<====");
            System.out.println("============================================================");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Enter Choice : ");

            try {
                choice = Integer.parseInt(sc.nextLine());

                switch (choice) {

                    case 1:
                        Register.registerMenu();
                        break;

                    case 2:
                        Login.loginMenu();
                        break;

                    case 3:
                        System.out.println("Thank You for Using Our System.");
                        System.out.println("Visit Again!");
                        break;

                    default:
                        System.out.println("Invalid Choice! Please enter 1, 2 or 3.");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid Input! Please enter numbers only.");
                choice = 0; 
            }

        } while (choice != 3);

        sc.close();
    }
}