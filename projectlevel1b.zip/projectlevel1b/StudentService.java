import java.util.Scanner;

public class StudentService {

    static Scanner sc = new Scanner(System.in);

    public static void studentMenu(Student student) {

        int choice;

        do {

            System.out.println("\n======================================");
            System.out.println("        STUDENT DASHBOARD");
            System.out.println("======================================");
            System.out.println("Welcome : " + student.getName());
            System.out.println("--------------------------------------");
            System.out.println("1. View Profile");
            System.out.println("2. Update Profile");
            System.out.println("3. Update Skills");
            System.out.println("4. Update CGPA");
            System.out.println("5. View Companies");
            System.out.println("6. Apply Company");
            System.out.println("7. View My Applications");
            System.out.println("8. View My Tasks");
            System.out.println("9. Update Task Status");
            System.out.println("10. View My Performance");
            System.out.println("11. Logout");
            System.out.print("Enter Choice : ");

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    StudentDAO.viewProfile(student);
                    break;

                case 2:
                    updateProfile(student);
                    break;

                case 3:
                    updateSkills(student);
                    break;

                case 4:
                    updateCGPA(student);
                    break;

                case 5:
                    CompanyDAO.viewCompanies();
                    break;

                case 6:
                      ApplicationDAO.applyForCompany(student);
                        break;
                case 7:
                   ApplicationDAO.viewMyApplications(student);
                   break;
               case 8:
                   TaskDAO.viewMyTasks(student);
                   break;

                case 9:
                  TaskDAO.updateTaskStatus(student);
                   break;

               case 10:
                 PerformanceDAO.viewStudentPerformance(student);
                 break;

               case 11:
               System.out.println("Logged Out Successfully...");
               break;

                default:
                    System.out.println("Invalid Choice!");

            }

        } while (choice != 11);
         
    }

    // ==========================
    // Update Profile
    // ==========================

    public static void updateProfile(Student student) {

        System.out.print("Enter New Name : ");
        student.setName(sc.nextLine());

        System.out.print("Enter New Password : ");
        student.setPassword(sc.nextLine());

        if (StudentDAO.updateProfile(student)) {

            System.out.println("\nProfile Updated Successfully.");

        } else {

            System.out.println("\nProfile Update Failed.");

        }

    }

    // ==========================
    // Update Skills
    // ==========================

    public static void updateSkills(Student student) {

        System.out.print("Enter Skills : ");

        String skills = sc.nextLine();

        if (StudentDAO.updateSkills(student.getStudentId(), skills)) {

            student.setSkills(skills);

            System.out.println("\nSkills Updated Successfully.");

        } else {

            System.out.println("\nUpdate Failed.");

        }

    }

    // ==========================
    // Update CGPA
    // ==========================

    public static void updateCGPA(Student student) {

        System.out.print("Enter New CGPA : ");

        double cgpa = sc.nextDouble();
        sc.nextLine();

        if (StudentDAO.updateCGPA(student.getStudentId(), cgpa)) {

            student.setCgpa(cgpa);

            System.out.println("\nCGPA Updated Successfully.");

        } else {

            System.out.println("\nUpdate Failed.");

        }

    }

}