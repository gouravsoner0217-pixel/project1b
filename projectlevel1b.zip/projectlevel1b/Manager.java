public class Manager {

    // Instance Variables
    private int managerId;
    private String name;
    private String username;
    private String password;

    // Default Constructor
    public Manager() {

    }

    // Parameterized Constructor
    public Manager(int managerId, String name, String username, String password) {
        this.managerId = managerId;
        this.name = name;
        this.username = username;
        this.password = password;
    }

    // Getters
    public int getManagerId() {
        return managerId;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    // Setters
    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Display Manager Details
    @Override
    public String toString() {
        return "\n========== MANAGER DETAILS ==========\n" +
               "Manager ID : " + managerId +
               "\nName       : " + name +
               "\nUsername   : " + username +
               "\n=====================================";
    }
}