import java.util.Scanner;

public class Login {

    static Scanner sc = new Scanner(System.in);

    public static void loginMenu() {

        int choice;

        do {

            System.out.println("\n==================================");
            System.out.println("             LOGIN");
            System.out.println("==================================");
            System.out.println("1. Student Login");
            System.out.println("2. HR Login");
            System.out.println("3. Manager Login");
            System.out.println("4. Back");
           

              while (true) {

            System.out.print("Enter Choice : ");

            if (sc.hasNextInt()) {

                choice = sc.nextInt();
                sc.nextLine();
                break;

            } else {

                System.out.println("❌ Invalid Input! TRY AGAIN.");
                sc.nextLine(); // Remove invalid input

            }

        }
            

            switch (choice) {

                case 1:
                    studentLogin();
                    break;

                case 2:
                    hrLogin();
                    break;

                case 3:
                    managerLogin();
                    break;

                case 4:
                    System.out.println("Returning...");
                    break;

                default:
                    System.out.println("Invalid Choice! TRY AGAIN.");

            }

        } while (choice != 4);

    }

    // ===========================
    // Student Login
    // ===========================
public static void studentLogin() {

    while (true) {

        System.out.print("Username : ");
        String username = sc.nextLine().trim();

        if (username.isEmpty()) {
            System.out.println("❌ Username cannot be empty.");
            continue;
        }

        System.out.print("Password : ");
        String password = sc.nextLine().trim();

        if (password.isEmpty()) {
            System.out.println("❌ Password cannot be empty.");
            continue;
        }

        Student student = StudentDAO.loginStudent(username, password);

        if (student != null) {

            System.out.println("\n✅ Login Successful!");
            System.out.println("Welcome " + student.getName());

            StudentService.studentMenu(student);
            break;

        } else {

            System.out.println("\n❌ Invalid Username or Password!");
            System.out.println("Please try again.\n");

        }

    }

}

    // ===========================
    // HR Login
    // ===========================

    public static void hrLogin() {

    while (true) {

        System.out.print("Username : ");
        String username = sc.nextLine().trim();

        if (username.isEmpty()) {
            System.out.println("❌ Username cannot be empty.");
            continue;
        }

        System.out.print("Password : ");
        String password = sc.nextLine().trim();

        if (password.isEmpty()) {
            System.out.println("❌ Password cannot be empty.");
            continue;
        }

        if (HRDAO.loginHR(username, password)) {

            System.out.println("\n✅ Login Successful!");
            HRService.hrMenu();
            break;

        } else {

            System.out.println("\n❌ Invalid Username or Password!");
            System.out.println("Please try again.\n");

        }

    }

}
    // ===========================
    // Manager Login
    // ===========================

    public static void managerLogin() {

    while (true) {

        System.out.print("Username : ");
        String username = sc.nextLine().trim();

        if (username.isEmpty()) {
            System.out.println("❌ Username cannot be empty.");
            continue;
        }

        System.out.print("Password : ");
        String password = sc.nextLine().trim();

        if (password.isEmpty()) {
            System.out.println("❌ Password cannot be empty.");
            continue;
        }

        if (ManagerDAO.loginManager(username, password)) {

            System.out.println("\n✅ Login Successful!");
            ManagerService.managerMenu();
            break;

        } else {

            System.out.println("\n❌ Invalid Username or Password!");
            System.out.println("Please try again.\n");

        }

    }

}

}