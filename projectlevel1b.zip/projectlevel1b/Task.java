public class Task {

    // Instance Variables
    private int taskId;
    private int studentId;
    private int managerId;
    private String taskName;
    private String status;

    // Default Constructor
    public Task() {

    }

    // Parameterized Constructor
    public Task(int taskId, int studentId, int managerId,
                String taskName, String status) {

        this.taskId = taskId;
        this.studentId = studentId;
        this.managerId = managerId;
        this.taskName = taskName;
        this.status = status;
    }

    // Getters

    public int getTaskId() {
        return taskId;
    }

    public int getStudentId() {
        return studentId;
    }

    public int getManagerId() {
        return managerId;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getStatus() {
        return status;
    }

    // Setters

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Display Task Details

    @Override
    public String toString() {

        return "\n========== TASK DETAILS ==========" +
               "\nTask ID     : " + taskId +
               "\nStudent ID  : " + studentId +
               "\nManager ID  : " + managerId +
               "\nTask Name   : " + taskName +
               "\nStatus      : " + status +
               "\n==================================";

    }

}
