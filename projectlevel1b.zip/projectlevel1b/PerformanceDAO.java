import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class PerformanceDAO {

    static Scanner sc = new Scanner(System.in);

    // ==========================================
    // Add Performance
    // ==========================================

    public static void addPerformance() {

        try {

            Performance performance = new Performance();

            System.out.print("Enter Student ID : ");
            performance.setStudentId(sc.nextInt());

            System.out.print("Enter Manager ID : ");
            performance.setManagerId(sc.nextInt());

            System.out.print("Enter Task ID : ");
            performance.setTaskId(sc.nextInt());

            System.out.print("Enter Marks (0-100) : ");
            performance.setMarks(sc.nextInt());
            sc.nextLine();

            // Generate Grade Automatically

            int marks = performance.getMarks();

            if (marks >= 90)
                performance.setGrade("A+");
            else if (marks >= 80)
                performance.setGrade("A");
            else if (marks >= 70)
                performance.setGrade("B");
            else if (marks >= 60)
                performance.setGrade("C");
            else if (marks >= 50)
                performance.setGrade("D");
            else
                performance.setGrade("F");

            System.out.print("Enter Remarks : ");
            performance.setRemarks(sc.nextLine());

            Connection con = DBConnection.getConnection();

            String sql =
            "INSERT INTO performance(student_id,manager_id,task_id,marks,grade,remarks) VALUES(?,?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, performance.getStudentId());
            ps.setInt(2, performance.getManagerId());
            ps.setInt(3, performance.getTaskId());
            ps.setInt(4, performance.getMarks());
            ps.setString(5, performance.getGrade());
            ps.setString(6, performance.getRemarks());

            if (ps.executeUpdate() > 0) {

                System.out.println("\nPerformance Added Successfully.");

            } else {

                System.out.println("\nFailed.");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    // ==========================================
    // View All Performance
    // ==========================================

    public static void viewAllPerformance() {

        try {

            Connection con = DBConnection.getConnection();

            String sql =
            "SELECT p.performance_id, s.name, p.task_id, p.marks, p.grade, p.remarks " +
            "FROM performance p " +
            "JOIN students s ON p.student_id = s.student_id";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            System.out.println("\n========== PERFORMANCE REPORT ==========");

            while (rs.next()) {

                System.out.println("--------------------------------------");
                System.out.println("Performance ID : " + rs.getInt("performance_id"));
                System.out.println("Student Name   : " + rs.getString("name"));
                System.out.println("Task ID        : " + rs.getInt("task_id"));
                System.out.println("Marks          : " + rs.getInt("marks"));
                System.out.println("Grade          : " + rs.getString("grade"));
                System.out.println("Remarks        : " + rs.getString("remarks"));

            }

            System.out.println("--------------------------------------");

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    // ==========================================
    // View Student Performance
    // ==========================================

    public static void viewStudentPerformance(Student student) {

        try {

            Connection con = DBConnection.getConnection();

            String sql =
            "SELECT * FROM performance WHERE student_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, student.getStudentId());

            ResultSet rs = ps.executeQuery();

            System.out.println("\n========== MY PERFORMANCE ==========");

            boolean found = false;

            while (rs.next()) {

                found = true;

                System.out.println("--------------------------------------");
                System.out.println("Task ID  : " + rs.getInt("task_id"));
                System.out.println("Marks    : " + rs.getInt("marks"));
                System.out.println("Grade    : " + rs.getString("grade"));
                System.out.println("Remarks  : " + rs.getString("remarks"));

            }

            if (!found) {

                System.out.println("No Performance Found.");

            }

            System.out.println("--------------------------------------");

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

}