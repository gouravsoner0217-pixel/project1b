import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class TaskDAO {

    static Scanner sc = new Scanner(System.in);

    // ==========================
    // Assign Task
    // ==========================

    public static void assignTask() {

        try {

            Task task = new Task();

            System.out.print("Enter Student ID : ");
            task.setStudentId(sc.nextInt());

            System.out.print("Enter Manager ID : ");
            task.setManagerId(sc.nextInt());
            sc.nextLine();

            System.out.print("Enter Task Name : ");
            task.setTaskName(sc.nextLine());

            task.setStatus("Pending");

            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO tasks(student_id,manager_id,task_name,status) VALUES(?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, task.getStudentId());
            ps.setInt(2, task.getManagerId());
            ps.setString(3, task.getTaskName());
            ps.setString(4, task.getStatus());

            if (ps.executeUpdate() > 0) {

                System.out.println("\nTask Assigned Successfully.");

            } else {

                System.out.println("\nTask Assignment Failed.");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    // ==========================
    // View Tasks
    // ==========================

    public static void viewTasks() {

        try {

            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM tasks";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                System.out.println("--------------------------------");
                System.out.println("Task ID     : " + rs.getInt("task_id"));
                System.out.println("Student ID  : " + rs.getInt("student_id"));
                System.out.println("Manager ID  : " + rs.getInt("manager_id"));
                System.out.println("Task Name   : " + rs.getString("task_name"));
                System.out.println("Status      : " + rs.getString("status"));
            }

            System.out.println("--------------------------------");

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    // ==========================
    // Update Task Status
    // ==========================

    public static void updateTaskStatus() {

        try {

            System.out.print("Enter Task ID : ");
            int taskId = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter New Status : ");
            String status = sc.nextLine();

            Connection con = DBConnection.getConnection();

            String sql = "UPDATE tasks SET status=? WHERE task_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, status);
            ps.setInt(2, taskId);

            if (ps.executeUpdate() > 0) {

                System.out.println("\nTask Updated Successfully.");

            } else {

                System.out.println("\nTask Not Found.");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

 
// ==========================================
// Student - View My Tasks
// ==========================================

public static void viewMyTasks(Student student) {

    try {

        Connection con = DBConnection.getConnection();

        String sql = "SELECT * FROM tasks WHERE student_id=?";

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setInt(1, student.getStudentId());

        ResultSet rs = ps.executeQuery();

        boolean found = false;

        System.out.println("\n========== MY TASKS ==========");

        while (rs.next()) {

            found = true;

            System.out.println("--------------------------------");
            System.out.println("Task ID     : " + rs.getInt("task_id"));
            System.out.println("Task Name   : " + rs.getString("task_name"));
            System.out.println("Status      : " + rs.getString("status"));

        }

        if (!found) {
            System.out.println("No Tasks Assigned.");
        }

        System.out.println("--------------------------------");

    } catch (Exception e) {
        e.printStackTrace();
    }
}


// ==========================================
// Student - Update Task Status
// ==========================================

public static void updateTaskStatus(Student student) {

    try {

        System.out.print("Enter Task ID : ");
        int taskId = sc.nextInt();
        sc.nextLine();

        System.out.println("\n1. In Progress");
        System.out.println("2. Completed");
        System.out.print("Choose Status : ");

        int choice = sc.nextInt();
        sc.nextLine();

        String status = "";

        switch (choice) {

            case 1:
                status = "In Progress";
                break;

            case 2:
                status = "Completed";
                break;

            default:
                System.out.println("Invalid Choice!");
                return;
        }

        Connection con = DBConnection.getConnection();

        String sql =
        "UPDATE tasks SET status=? WHERE task_id=? AND student_id=?";

        PreparedStatement ps = con.prepareStatement(sql);

        ps.setString(1, status);
        ps.setInt(2, taskId);
        ps.setInt(3, student.getStudentId());

        int row = ps.executeUpdate();

        if (row > 0) {

            System.out.println("\nTask Status Updated Successfully.");

        } else {

            System.out.println("\nTask Not Found.");

        }

    } catch (Exception e) {

        e.printStackTrace();

    }

}
}
    

