public class Application {

    private int applicationId;
    private int studentId;
    private int companyId;
    private String applicationDate;
    private String status;

    // Default Constructor
    public Application() {

    }

    // Parameterized Constructor
    public Application(int applicationId, int studentId, int companyId,
                       String applicationDate, String status) {

        this.applicationId = applicationId;
        this.studentId =studentId;
        this.companyId = companyId;
        this.applicationDate = applicationDate;
        this.status = status;
    }

    // Getters

    public int getApplicationId() {
        return applicationId;
    }

    public int getStudentId() {
        return studentId;
    }

    public int getCompanyId() {
        return companyId;
    }

    public String getApplicationDate() {
        return applicationDate;
    }

    public String getStatus() {
        return status;
    }

    // Setters

    public void setApplicationId(int applicationId) {
        this.applicationId = applicationId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }

    public void setApplicationDate(String applicationDate) {
        this.applicationDate = applicationDate;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Display

    @Override
    public String toString() {

        return "\n========== APPLICATION ==========" +
               "\nApplication ID : " + applicationId +
               "\nStudent ID     : " + studentId +
               "\nCompany ID     : " + companyId +
               "\nApplied Date   : " + applicationDate +
               "\nStatus         : " + status +
               "\n=================================";

    }

}