public class Company {

    // Instance Variables
    private int companyId;
    private String companyName;
    private String requiredSkills;
    private double minimumCgpa;
    private int vacancies;

    // Default Constructor
    public Company() {

    }

    // Parameterized Constructor
    public Company(int companyId, String companyName, String requiredSkills,
                   double minimumCgpa, int vacancies) {

        this.companyId = companyId;
        this.companyName = companyName;
        this.requiredSkills = requiredSkills;
        this.minimumCgpa = minimumCgpa;
        this.vacancies = vacancies;
    }

    // Getters

    public int getCompanyId() {
        return companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getRequiredSkills() {
        return requiredSkills;
    }

    public double getMinimumCgpa() {
        return minimumCgpa;
    }

    public int getVacancies() {
        return vacancies;
    }

    // Setters

    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setRequiredSkills(String requiredSkills) {
        this.requiredSkills = requiredSkills;
    }

    public void setMinimumCgpa(double minimumCgpa) {
        this.minimumCgpa = minimumCgpa;
    }

    public void setVacancies(int vacancies) {
        this.vacancies = vacancies;
    }

    // Display Company Details

    @Override
    public String toString() {

        return "\n========== COMPANY DETAILS ==========\n" +
               "Company ID      : " + companyId +
               "\nCompany Name    : " + companyName +
               "\nRequired Skills : " + requiredSkills +
               "\nMinimum CGPA    : " + minimumCgpa +
               "\nVacancies       : " + vacancies +
               "\n=====================================";
    }
}