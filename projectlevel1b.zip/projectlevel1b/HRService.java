import java.util.Scanner;

public class HRService {

    static Scanner sc = new Scanner(System.in);

    public static void hrMenu() {

        int choice;

        do {

            System.out.println("\n======================================");
            System.out.println("           HR DASHBOARD");
            System.out.println("======================================");
            System.out.println("1. Add Company");
            System.out.println("2. View Companies");
            System.out.println("3. Delete Company");
            System.out.println("4. View Students");
            System.out.println("5. Filter Students By CGPA");
            System.out.println("6. View All Applications");
            System.out.println("7. Approve Application");
            System.out.println("8. Reject Application");
            System.out.println("9. Shortlist Application");
            System.out.println("10. View Shortlisted Applications");
            System.out.println("11. Logout");
            System.out.print("Enter Choice : ");

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    CompanyDAO.addCompany();
                    break;

                case 2:
                    CompanyDAO.viewCompanies();
                    break;

                case 3:
                    CompanyDAO.deleteCompany();
                    break;

                case 4:
                    StudentDAO.viewAllStudents();
                    break;

                case 5:
                    filterByCGPA();
                    break;
                
                 case 6 :
                    ApplicationDAO.viewAllApplications();
                    break;
                    case 7:
                        ApplicationDAO.approveApplication();
                        break;
                        case 8:
                            ApplicationDAO.rejectApplication();
                            break;
                        case 9:
                            ApplicationDAO.shortlistApplication();
                            break;
                            case 10:
                               ApplicationDAO.viewShortlistedApplications();
                               break;

                case 11:
                    System.out.println("\nLogged Out Successfully...");
                    break;

                default:
                    System.out.println("\nInvalid Choice!");

            }

        } while (choice != 11);

    }

    // ==========================
    // Filter Students by CGPA
    // ==========================

    public static void filterByCGPA() {

        System.out.print("\nEnter Minimum CGPA : ");

        double cgpa = sc.nextDouble();
        sc.nextLine();

        StudentDAO.filterStudentsByCGPA(cgpa);

    }

}